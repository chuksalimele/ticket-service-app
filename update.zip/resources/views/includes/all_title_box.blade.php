
	<div class="all-title-box">
		<div class="container text-center">
                    @yield('box_title')
		</div>
	</div>