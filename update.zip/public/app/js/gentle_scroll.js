
$(document).ready(function () {

    
    $('a[data-scroll-to^="#"]').on('click', function () {
        var id = $(this).attr('data-scroll-to');
        $('html, body').animate({
            scrollTop: $(id).offset().top - 90
        }, 1000);
    });



});

